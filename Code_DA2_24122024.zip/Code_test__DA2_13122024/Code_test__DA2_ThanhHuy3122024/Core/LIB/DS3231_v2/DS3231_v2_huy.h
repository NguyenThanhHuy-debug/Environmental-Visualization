/*
 * DS3231_v2_huy.h
 *
 *  Created on: Dec 3, 2024
 *      Author: user
 */

#ifndef LIB_DS3231_V2_DS3231_V2_HUY_H_
#define LIB_DS3231_V2_DS3231_V2_HUY_H_

#include "stm32f4xx_hal.h"  // Adjust to your MCU's HAL header

#define DS3231_ADDRESS 0xD0



#endif /* LIB_DS3231_V2_DS3231_V2_HUY_H_ */
